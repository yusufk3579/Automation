package diary;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.Test;

public class tust {
	
	
	
	
	@Test
	public void gio() throws IOException {
		Properties prop = new Properties();
		FileInputStream fis;

			fis = new FileInputStream("C:\\Users\\fathi\\eclipse-workspace\\TestNextGen\\src\\diary\\data.properties");
			prop.load(fis);
		System.out.println(prop.getProperty("password"));
		System.out.println("gio");
	}
	
	@Test
	public void again() {
		System.out.println("Again");
	}

}
