package diary;

import org.testng.ITestListener;
import org.testng.ITestResult;

public class Listen implements ITestListener{
	
	@Override
	public void onTestFailure(ITestResult result) {
		
		//Screenshot
		
		
	}
public void onTestSuccess(ITestResult result) {
		
		//Success message
	System.out.println("Success"+result.getName());
		
		
	}


}
