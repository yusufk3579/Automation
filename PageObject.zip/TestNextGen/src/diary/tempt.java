package diary;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class tempt {
	
	@Parameters({"url"})
	@Test(groups= {"test"}, enabled= true)
	public void tempt(String url) {
		System.out.println("Tempt"+url);
	}
	
	
	@Test(groups= {"test"}, timeOut = 4000)
	public void tant() {
		System.out.println("tant");
	}
	
	@Test(dataProvider="naming")
	public void Tant(String name, String pwd) {
		System.out.println(name + pwd);
	}
	
	@Test
	public void Tantra() {
		System.out.println("Tantra");
	}

	@Test
	public void tantra() {
		System.out.println("tantra");
	}
	@DataProvider
	public Object[][] naming() {
		
		Object[][] data = new Object[3][2];
		
		//System.out.println("uname");
		//System.out.println("pwd");
		data[0][0] = "00";
		data[0][1] = "01";
		
		data[1][0] = "10";
		data[1][1] = "11";
		
		data[2][0] = "20";
		data[2][1] = "21";
		
		return data;
	}
}
