package main;

import java.util.logging.LogManager;
import java.util.logging.Logger;
import org.apache.logging.log4j.*;

public class Demo {
	
	 public static Logger log = Logger.getLogger(Demo.class.getName());
	 
	 public static void main(String[] args) {
		//log.debug("I am debiggu=ing");
		log.info("I am info=ing");
		//log.fatal("I am fat=ing");

		//log.error("I am err=ing");

		
	}

}
