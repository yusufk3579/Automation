package basics;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DataDriven{
	
	public ArrayList<String> getdata(String test) throws IOException {

		
		//fileinputStream
		ArrayList<String> ar = new ArrayList<String>();
		
		FileInputStream fis = new FileInputStream("D:\\eclipse\\Book1.xlsx");
		//Workbook
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		int numofsheets=wb.getNumberOfSheets();
		
		for(int i=0;i<numofsheets;i++) {
			if(wb.getSheetName(i).equalsIgnoreCase("testdata")){
			XSSFSheet sheet = wb.getSheetAt(i);
			Iterator<Row> rows= sheet.iterator();
			Row firstrow = rows.next();
			Iterator<Cell> c = firstrow.cellIterator();
			
			
			int k=0;
			int col=0;
			while(c.hasNext()) {
				Cell value=c.next();
				if(value.getStringCellValue().equalsIgnoreCase("Tc")){
					//desired column
					
					col=k;
					
					}
				k++;  
				}
			
			
				System.out.println(col);
				while(rows.hasNext()) {
					Row r= rows.next();
					if(r.getCell(col).getStringCellValue().equalsIgnoreCase(test)) {
						Iterator<Cell> cel = r.cellIterator();
					while(cel.hasNext()) {
						ar.add(cel.next().getStringCellValue());
					}	
					
					}
					
				}
			}
			
		}
		return ar;
	}
	

}
