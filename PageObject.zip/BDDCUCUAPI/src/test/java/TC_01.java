import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class TC_01 {
	
	@Test
	public void tc_get() {
		given()
		.when()
		.get("URL")
		.then()
		.statusCode(200)
		.statusLine("Line")	
		.assertThat().body("City", equalTo("Hyd"))
		.header("Con","html");
	}

}
