package Test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SelectDropDown {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		public static void main(String[] args) {
			
			System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			
			
			Select sel = new Select(driver.findElement(By.name("country")));
			sel.selectByVisibleText("ANTARTCTICA");
			
			
		}
		

	}

}
