import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.internal.junit.ArrayAsserts;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.*;


@Test
public class DFunctions {

	int code=given().
	auth().preemptive().basic("user", "pass").when().get("").getStatusCode();
	
	
	
}
