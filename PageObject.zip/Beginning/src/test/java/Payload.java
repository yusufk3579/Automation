
public class Payload {
	

	Issuetype issuetype;
	Project project;
	String summary;
	String Description;
	
	public Payload(String summary, String description, Issuetype issuetype, Project project) {

		this.summary = summary;
		this.Description=description;
		
	}

	public Issuetype getIssuetype() {
		return issuetype;
	}
	public void setIssuetype(Issuetype issuetype) {
		this.issuetype = issuetype;
	}
	public Project getProject() {
		return project;
	}
	public void setProject(Project project) {
		this.project = project;
	}

	
	
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}

	

}
