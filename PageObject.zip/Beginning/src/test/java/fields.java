
public class fields {
	
	Payload fields;

	public fields(Payload payload) {
		this.fields = payload;
	}

	public Payload getFields() {
		return fields;
	}

	public void setFields(Payload fields) {
		this.fields = fields;
	}

}
