
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class FinalPayload {

	
	public static void main(String[] args) throws JsonProcessingException {
		Issuetype issue = new Issuetype("Task");
		
		ObjectMapper objMap = new ObjectMapper();
		
		String mydata=objMap.writerWithDefaultPrettyPrinter().writeValueAsString(issue);
		System.out.println(mydata);
	}

	
	
	
}
