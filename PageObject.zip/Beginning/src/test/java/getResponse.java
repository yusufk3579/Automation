import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.internal.junit.ArrayAsserts;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

import static io.restassured.RestAssured.*;

public class getResponse {

	@Test
	public void testResponsecode(){
		Response resp=RestAssured.
						get("https://samples.openweathermap.org/data/2.5/weather?q=London,uk&appid=439d4b804bc8187953eb36d2a8c26a02");
		
		int code = resp.getStatusCode();
		Assert.assertEquals(code, 200);
	
	}
	
	@Test
	public void testResponsebody(){
		Response respo=RestAssured.
						get("https://samples.openweathermap.org/data/2.5/weather?q=London,uk&appid=439d4b804bc8187953eb36d2a8c26a02");
		
			ResponseBody boby=respo.getBody();
			System.out.println(boby);
	}
	
	
}
