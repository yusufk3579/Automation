package Testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class LoginApp {
	
	@Test
	public void Login() {
		
		System.setProperty("jio", "fbhviu");
		WebDriver driver  = new ChromeDriver();
		driver.get("google.com");
		
		
	}

}
