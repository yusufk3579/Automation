package ObjectRep;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class YahooLoginPage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		WebDriver driver;
		By uname = By.xpath("//");
		By pwd = By.xpath("pasbvhio");
		By go = By.name("name");
		
			
	}

}
