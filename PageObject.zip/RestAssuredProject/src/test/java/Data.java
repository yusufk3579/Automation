import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.sun.xml.xsom.impl.scd.Iterators.Map;

import static io.restassured.RestAssured.*;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static  io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.HashMap;

public class Data {
	
	@DataProvider(name="testdata")
	Object data() {
		
		return new Object[][] {
			{5, "json"}
			
		};
		
	}
	
	@Test(dataProvider = "testdata")
	void tempdel(int v1,String s1) {
		baseURI = "http://localhost:3000";
		
		JSONObject obj = new JSONObject();
		
		obj.put("id", v1);
		obj.put("name", s1);
		
		given().
			body(obj.toString()).
		when().
			delete("/sub").
		then().
			statusCode(404);
		
	}
	@Test(dataProvider = "testdata")
	void temptyu(int v1,String s1) {
		baseURI = "http://localhost:3000";
		
		JSONObject obj = new JSONObject();
		
		obj.put("id", v1);
		obj.put("name", s1);
		
		given().
			body(obj.toString()).
		when().
			post("/sub").
		then().
			statusCode(201);
		
	}	

}
