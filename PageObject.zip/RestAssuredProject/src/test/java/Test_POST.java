
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.sun.xml.xsom.impl.scd.Iterators.Map;

import static io.restassured.RestAssured.*;
import io.restassured.response.Response;
import static  io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.HashMap;

public class Test_POST {
	
	@Test
	void postt() {
		HashMap<String, Object> map = new HashMap<String,Object>();
		((java.util.Map<String, Object>) map).put("name", "Raghav");
		((java.util.Map<String, Object>) map).put("job", "Teacher");
		
		System.out.println(map);
		
		JSONObject jobj = new JSONObject(map);
		
		jobj.put("name", "vakue");
		
		System.out.println(jobj);
		System.out.println(jobj.toJSONString());
		
		given().
		body(jobj.toJSONString()).
		when().
		post("https://reqres.in/api/users").
		then().
		statusCode(201);
	}
	
	@Test
	void up() {
		JSONObject ob = new JSONObject();
		ob.put("Yusuf", "victor");
		
		given().
		body(ob.toJSONString()).
		when().
		put("https://reqres.in/api/users");
		
	}
	@Test
	void pat() {
		JSONObject ob = new JSONObject();
		ob.put("Yufdfsuf", "victsdfor");
		
		given().
		body(ob.toJSONString()).
		when().
		patch("https://reqres.in/api/users");
		
	}
	@Test
	void upp() {
		JSONObject ob = new JSONObject();
		ob.put("Yusuf", "victor");
		
		given().
		body(ob.toJSONString()).
		when().
		put("https://reqres.in/api/users");
		
	}
	@Test
	void del() {
		
		given().
		delete("https://reqres.in/api/users").
		then().
		statusCode(204);
		
	}

}
