
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.sun.xml.xsom.impl.scd.Iterators.Map;

import static io.restassured.RestAssured.*;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static  io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.HashMap;
public class TestAPIS {
	
	
	@Test
	void tempt() {
		
		
		JSONObject obj = new JSONObject();
		obj.put("id", 3);
		obj.put("name", "Api");
		
		baseURI="http://localhost:3000";
 
		given().
			contentType(ContentType.JSON).
			accept(ContentType.JSON).
			header("Content-Type","application/JSON").
			body(obj.toJSONString()).
		when().
			post("/sub").
		then().
			statusCode(201);
		
		
	}

	
}
