package SDET;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.mapper.factory.JsonbObjectMapperFactory;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TC_002 {
	
	@Test
	public void TC_002_POST() {
		//URI
		RestAssured.baseURI = "http://restapi.demoqa.com/customer";
		//Request
		RequestSpecification req=RestAssured.given();
		//JSON BODY
		JSONObject obj = new JSONObject();
		
		obj.put("firstname", "Yus");
		obj.put("Lname", "Khan");
		obj.put("uname","zamfiza");
		obj.put("pwd", "Pass");
		obj.put("Email", "zamfiza@gmail.com");
		
		//Save header as we are posting the method
		req.header("Content-type", "application/JSON");
		
		//convert the body to JSON
		req.body(obj.toJSONString());
		
		//Response POST
		Response res =req.request(Method.POST,"/register");
		
		//Print response in Console window
		
		String resp = res.getBody().asString();
		
		//Success code validation
		String success = res.jsonPath().get("SuccessCode");
		
	}

}
