package SDET;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TC005_JSONResponse {
	
	@Test
	public void JSON() {
		
		RestAssured.baseURI="http://restapi.demoqa.com/utilities/weather/city";
		
		RequestSpecification req = RestAssured.given();
		
		Response resp = req.request("Method.GET", "/ghu");
		
		String respB = resp.getBody().asString();
		
		Assert.assertEquals(respB.contains("Delhi"), true);
	}

}
