package SDET;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.authentication.PreemptiveBasicAuthScheme;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TC006_Auth {
	
	
	@Test
	public void Auth() {
		RestAssured.baseURI=";";
		//Auth-code
		PreemptiveBasicAuthScheme p = new PreemptiveBasicAuthScheme();
		p.setUserName("uname");
		p.setPassword("pwd");
		
		RestAssured.authentication=p;
		
		//req
		RequestSpecification req = RestAssured.given();
		//res
		Response res = req.request(Method.GET, "");
		 
	}


}
