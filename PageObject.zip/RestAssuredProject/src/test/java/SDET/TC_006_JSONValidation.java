package SDET;

import org.testng.Assert;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TC_006_JSONValidation {
	
	public void TC006_JSONValid() {
		
		RestAssured.baseURI = "vnjfkdnl;k";
		RequestSpecification req = RestAssured.given();
		Response res = req.request("Method.GET", "udsi");
		
		
		JsonPath json = res.jsonPath();
		
		json.get("City");
		json.get("Temperature");
		json.get("Humidity");
		json.get("WeatherDescription");
		json.get("WindSpeed");
		json.get("WindDirectionDegree");
		
		Assert.assertEquals(json.get("City"), "Hyderabad");
		
		
		
	}

}
