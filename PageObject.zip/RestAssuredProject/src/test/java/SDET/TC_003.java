package SDET;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TC_003 {
	
	@Test
	public void TC_003_GET() {
		//URI
		RestAssured.baseURI="https://maps.googleapis.com";
		//Req
		RequestSpecification req = RestAssured.given();
		//Res
		Response resp = req.request(Method.GET, "/fg/kl");
		
		//Print response
		String responseBody=resp.getBody().asString();
		
		//VAlidate Headers
		String head= resp.header("Content-type");
		
		
	}

}
