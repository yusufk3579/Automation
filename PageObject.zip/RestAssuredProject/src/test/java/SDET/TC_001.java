package SDET;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TC_001 {
	
	@Test
	public void TC_001_GET_01() {
		
		//URI
		RestAssured.baseURI="http://restapi.demoqa.cam/utilities/weather/city";
		//Request
		RequestSpecification req = RestAssured.given();
		//Res
		Response res = req.request(Method.GET, "/Hyderabad");
		
		
		//print response in console window
		String respbody=res.getBody().asString();
		System.out.println(respbody);
		
		//status code validation
		int code = res.getStatusCode();
		Assert.assertEquals(code, 200);
		
		//status line verificaiton
		String statusline= res.statusLine();
		Assert.assertEquals(statusline, "HTTP/1.1 200 OK");
	}

}
