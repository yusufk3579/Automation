package SDET;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TC_004_Headers {
	
	@Test
	public void TC_004_allHeaders() {
		
		RestAssured.baseURI="https://maps.googleapis.com";
		
		RequestSpecification req = RestAssured.given();
		
		Response resp = req.request(Method.GET,"/der");
		
		String respbody=resp.getBody().asString();
		
		Headers headers = resp.headers();
		
		for(Header header:headers) {
			System.out.println(header.getName()+" "+header.getValue());
		}
		
	}

}
