package Utiils;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class ExcelUtils {

	public static void rowcount() throws IOException {
	XSSFWorkbook wb = new XSSFWorkbook("D:\\eclipse\\Book1.xlsx");

	XSSFSheet sheet = wb.getSheet("testdata");
	int rowcount = sheet.getPhysicalNumberOfRows();
	System.out.println(rowcount);
}
	public static void celldata() throws IOException {
		XSSFWorkbook wb = new XSSFWorkbook("D:\\eclipse\\Book1.xlsx");
		XSSFSheet sheet = wb.getSheet("testdata");
		int rowcount = sheet.getPhysicalNumberOfRows();
		
		System.out.println(sheet.getRow(1).getCell(0).getStringCellValue());
	}
	public static void main(String[] args) throws IOException {
		rowcount();
		celldata(); 
	}
	
	
	

}
